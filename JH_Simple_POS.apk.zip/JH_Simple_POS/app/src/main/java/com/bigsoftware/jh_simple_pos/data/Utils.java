package com.bigsoftware.jh_simple_pos.data;

/**
 * Created by shanesepac on 4/15/19.
 */

public class Utils {

    static long getDateTime(){
        //TODO: Implement code that gets timestamp. System.currentTimeMillis() doesnt always work...
        return System.currentTimeMillis();
    }

    static boolean internetAvailable(){
        //TODO: Finish method
        return true;
    }

}
